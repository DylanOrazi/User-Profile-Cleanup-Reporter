# User Profile Cleanup Reporter
# Safe reporting tool only - does not delete or move files

# -----------------------------
# 1. Setup
# -----------------------------

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ReportsFolder = Join-Path $ProjectRoot "Reports"

if (!(Test-Path $ReportsFolder)) {
    New-Item -ItemType Directory -Path $ReportsFolder | Out-Null
}

$Timestamp = Get-Date -Format "yyyy-MM-dd_HHmm"

$FolderSummaryCsv = Join-Path $ReportsFolder "Folder_Summary_$Timestamp.csv"
$LargeFilesCsv = Join-Path $ReportsFolder "Large_Files_$Timestamp.csv"
$OldFilesCsv = Join-Path $ReportsFolder "Old_Files_$Timestamp.csv"
$FileTypeBreakdownCsv = Join-Path $ReportsFolder "File_Type_Breakdown_$Timestamp.csv"
$SummaryReportTxt = Join-Path $ReportsFolder "Cleanup_Summary_Report_$Timestamp.txt"
$LogFile = Join-Path $ReportsFolder "Cleanup_Reporter_Log_$Timestamp.txt"

$LargeFileThresholdMB = 100
$OldFileThresholdDays = 90
$ScanStartTime = Get-Date

$UserProfile = $env:USERPROFILE

$FoldersToScan = @(
    @{ Name = "Downloads"; Path = Join-Path $UserProfile "Downloads" },
    @{ Name = "Desktop"; Path = Join-Path $UserProfile "Desktop" },
    @{ Name = "Documents"; Path = Join-Path $UserProfile "Documents" },
    @{ Name = "Pictures"; Path = Join-Path $UserProfile "Pictures" },
    @{ Name = "Videos"; Path = Join-Path $UserProfile "Videos" },
    @{ Name = "Music"; Path = Join-Path $UserProfile "Music" }
)

$FolderSummary = @()
$LargeFiles = @()
$OldFiles = @()
$FileTypeBreakdown = @()
$Errors = @()

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host " User Profile Cleanup Reporter" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "Scanning common user folders..." -ForegroundColor Yellow
Write-Host "This tool only reports. It does not delete files." -ForegroundColor Green
Write-Host ""

# -----------------------------
# 2. Helper Functions
# -----------------------------

function Convert-BytesToMB {
    param (
        [double]$Bytes
    )

    return [math]::Round($Bytes / 1MB, 2)
}

function Get-FileCategory {
    param (
        [string]$Extension
    )

    $ext = $Extension.ToLower()

    switch ($ext) {
        ".pdf" { return "PDF" }

        ".doc" { return "Documents" }
        ".docx" { return "Documents" }
        ".txt" { return "Documents" }
        ".rtf" { return "Documents" }

        ".xls" { return "Spreadsheets" }
        ".xlsx" { return "Spreadsheets" }
        ".csv" { return "Spreadsheets" }

        ".ppt" { return "Presentations" }
        ".pptx" { return "Presentations" }

        ".jpg" { return "Images" }
        ".jpeg" { return "Images" }
        ".png" { return "Images" }
        ".gif" { return "Images" }
        ".webp" { return "Images" }
        ".bmp" { return "Images" }

        ".mp4" { return "Videos" }
        ".mov" { return "Videos" }
        ".avi" { return "Videos" }
        ".mkv" { return "Videos" }
        ".wmv" { return "Videos" }

        ".mp3" { return "Audio" }
        ".wav" { return "Audio" }
        ".m4a" { return "Audio" }

        ".zip" { return "Archives" }
        ".rar" { return "Archives" }
        ".7z" { return "Archives" }

        ".exe" { return "Executables" }
        ".msi" { return "Executables" }

        ".ps1" { return "Scripts" }
        ".bat" { return "Scripts" }
        ".cmd" { return "Scripts" }
        ".py" { return "Scripts" }
        ".js" { return "Scripts" }
        ".html" { return "Scripts" }
        ".css" { return "Scripts" }
        ".cpp" { return "Scripts" }

        default {
            if ([string]::IsNullOrWhiteSpace($ext)) {
                return "No Extension"
            }
            else {
                return "Other"
            }
        }
    }
}

# -----------------------------
# 3. Scan Folders
# -----------------------------

foreach ($Folder in $FoldersToScan) {
    $FolderName = $Folder.Name
    $FolderPath = $Folder.Path

    Write-Host "Scanning $FolderName..." -ForegroundColor Cyan

    if (!(Test-Path $FolderPath)) {
        $Errors += "Folder not found: $FolderPath"
        continue
    }

    try {
        $Files = Get-ChildItem -Path $FolderPath -Recurse -File -ErrorAction SilentlyContinue

        $FileCount = $Files.Count
        $TotalSizeBytes = ($Files | Measure-Object -Property Length -Sum).Sum

        if ($null -eq $TotalSizeBytes) {
            $TotalSizeBytes = 0
        }

        $TotalSizeMB = Convert-BytesToMB -Bytes $TotalSizeBytes

        $OldestFile = $Files | Sort-Object LastWriteTime | Select-Object -First 1
        $NewestFile = $Files | Sort-Object LastWriteTime -Descending | Select-Object -First 1

        $OldestFileDate = if ($OldestFile) { $OldestFile.LastWriteTime } else { "N/A" }
        $NewestFileDate = if ($NewestFile) { $NewestFile.LastWriteTime } else { "N/A" }

        $Recommendation = "No major cleanup concern detected."

        if ($TotalSizeMB -ge 5000) {
            $Recommendation = "High storage use. Review large files and old files."
        }
        elseif ($TotalSizeMB -ge 1000) {
            $Recommendation = "Moderate storage use. Consider reviewing old files."
        }
        elseif ($FileCount -ge 1000) {
            $Recommendation = "Large number of files. Consider organizing this folder."
        }

        $FolderSummary += [PSCustomObject]@{
            FolderName          = $FolderName
            FolderPath          = $FolderPath
            FileCount           = $FileCount
            TotalSizeMB         = $TotalSizeMB
            OldestFileDate      = $OldestFileDate
            NewestFileDate      = $NewestFileDate
            Recommendation      = $Recommendation
        }

        # Large files
        $LargeFiles += $Files |
            Where-Object { $_.Length -ge ($LargeFileThresholdMB * 1MB) } |
            Select-Object @{
                Name = "Folder"
                Expression = { $FolderName }
            }, @{
                Name = "FileName"
                Expression = { $_.Name }
            }, @{
                Name = "FullPath"
                Expression = { $_.FullName }
            }, @{
                Name = "SizeMB"
                Expression = { Convert-BytesToMB -Bytes $_.Length }
            }, @{
                Name = "Extension"
                Expression = { $_.Extension }
            }, @{
                Name = "LastModified"
                Expression = { $_.LastWriteTime }
            }

        # Old files
        $OldFiles += $Files |
            Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-$OldFileThresholdDays) } |
            Select-Object @{
                Name = "Folder"
                Expression = { $FolderName }
            }, @{
                Name = "FileName"
                Expression = { $_.Name }
            }, @{
                Name = "FullPath"
                Expression = { $_.FullName }
            }, @{
                Name = "SizeMB"
                Expression = { Convert-BytesToMB -Bytes $_.Length }
            }, @{
                Name = "Extension"
                Expression = { $_.Extension }
            }, @{
                Name = "LastModified"
                Expression = { $_.LastWriteTime }
            }

        # File type breakdown
        $Breakdown = $Files |
            Group-Object { Get-FileCategory -Extension $_.Extension } |
            ForEach-Object {
                $CategoryFiles = $_.Group
                $CategorySizeBytes = ($CategoryFiles | Measure-Object -Property Length -Sum).Sum

                if ($null -eq $CategorySizeBytes) {
                    $CategorySizeBytes = 0
                }

                [PSCustomObject]@{
                    FolderName   = $FolderName
                    FileCategory = $_.Name
                    FileCount    = $_.Count
                    TotalSizeMB  = Convert-BytesToMB -Bytes $CategorySizeBytes
                }
            }

        $FileTypeBreakdown += $Breakdown
    }
    catch {
        $Errors += "Error scanning $FolderPath - $($_.Exception.Message)"
    }
}

# -----------------------------
# 4. Export CSV Reports
# -----------------------------

$FolderSummary | Export-Csv -Path $FolderSummaryCsv -NoTypeInformation -Encoding UTF8
$LargeFiles | Sort-Object SizeMB -Descending | Export-Csv -Path $LargeFilesCsv -NoTypeInformation -Encoding UTF8
$OldFiles | Sort-Object LastModified | Export-Csv -Path $OldFilesCsv -NoTypeInformation -Encoding UTF8
$FileTypeBreakdown | Sort-Object FolderName, FileCategory | Export-Csv -Path $FileTypeBreakdownCsv -NoTypeInformation -Encoding UTF8

# -----------------------------
# 5. Create TXT Summary Report
# -----------------------------

$ScanEndTime = Get-Date
$Duration = $ScanEndTime - $ScanStartTime

$TotalFilesScanned = ($FolderSummary | Measure-Object -Property FileCount -Sum).Sum
$TotalStorageMB = ($FolderSummary | Measure-Object -Property TotalSizeMB -Sum).Sum

if ($null -eq $TotalFilesScanned) {
    $TotalFilesScanned = 0
}

if ($null -eq $TotalStorageMB) {
    $TotalStorageMB = 0
}

$TopFolders = $FolderSummary | Sort-Object TotalSizeMB -Descending | Select-Object -First 3
$TopLargeFiles = $LargeFiles | Sort-Object SizeMB -Descending | Select-Object -First 10
$OldFileCount = $OldFiles.Count
$LargeFileCount = $LargeFiles.Count

$Report = @"
User Profile Cleanup Reporter
=============================

Scan Start Time:
$ScanStartTime

Scan End Time:
$ScanEndTime

Scan Duration:
$($Duration.Hours) hours, $($Duration.Minutes) minutes, $($Duration.Seconds) seconds

User Profile:
$UserProfile

Folders Scanned:
Downloads, Desktop, Documents, Pictures, Videos, Music

Cleanup Thresholds:
Large File Threshold: $LargeFileThresholdMB MB
Old File Threshold: $OldFileThresholdDays days

Overall Summary:
Total Files Scanned: $TotalFilesScanned
Total Storage Scanned: $([math]::Round($TotalStorageMB, 2)) MB
Large Files Found: $LargeFileCount
Old Files Found: $OldFileCount

Top Storage Folders:
$(
if ($TopFolders.Count -gt 0) {
    ($TopFolders | ForEach-Object {
        "$($_.FolderName): $($_.TotalSizeMB) MB, $($_.FileCount) files"
    }) -join "`n"
}
else {
    "No folder summary data found."
}
)

Top Large Files:
$(
if ($TopLargeFiles.Count -gt 0) {
    ($TopLargeFiles | ForEach-Object {
        "$($_.FileName) - $($_.SizeMB) MB - $($_.Folder)"
    }) -join "`n"
}
else {
    "No files larger than $LargeFileThresholdMB MB were found."
}
)

Reports Created:
Folder Summary CSV:
$FolderSummaryCsv

Large Files CSV:
$LargeFilesCsv

Old Files CSV:
$OldFilesCsv

File Type Breakdown CSV:
$FileTypeBreakdownCsv

Log File:
$LogFile

Cleanup Recommendations:
- Review the Large Files report for files that may no longer be needed.
- Review the Old Files report for files older than $OldFileThresholdDays days.
- Review the File Type Breakdown report to see which file categories use the most space.
- Move important files to backup storage before deleting anything manually.
- This tool does not delete, move, or modify files.

Errors:
$(
if ($Errors.Count -eq 0) {
    "No errors recorded."
}
else {
    ($Errors -join "`n")
}
)

Final Status:
Scan completed successfully.

"@

$Report | Out-File -FilePath $SummaryReportTxt -Encoding UTF8

# -----------------------------
# 6. Create Log File
# -----------------------------

$Log = @"
User Profile Cleanup Reporter Log
================================

Scan completed on:
$ScanEndTime

Reports folder:
$ReportsFolder

Files generated:
$FolderSummaryCsv
$LargeFilesCsv
$OldFilesCsv
$FileTypeBreakdownCsv
$SummaryReportTxt

Errors:
$(
if ($Errors.Count -eq 0) {
    "No errors recorded."
}
else {
    ($Errors -join "`n")
}
)

Note:
This script only scans and reports. It does not delete, move, or modify files.
"@

$Log | Out-File -FilePath $LogFile -Encoding UTF8

# -----------------------------
# 7. Console Output
# -----------------------------

Write-Host ""
Write-Host "Scan complete!" -ForegroundColor Green
Write-Host "Reports saved to:" -ForegroundColor Cyan
Write-Host $ReportsFolder -ForegroundColor White
Write-Host ""
Write-Host "Generated reports:" -ForegroundColor Yellow
Write-Host "Folder Summary CSV: $FolderSummaryCsv"
Write-Host "Large Files CSV: $LargeFilesCsv"
Write-Host "Old Files CSV: $OldFilesCsv"
Write-Host "File Type Breakdown CSV: $FileTypeBreakdownCsv"
Write-Host "Summary Report TXT: $SummaryReportTxt"
Write-Host "Log File: $LogFile"
Write-Host ""
Write-Host "Reminder: This tool did not delete or modify any files." -ForegroundColor Green

Read-Host "Press Enter to close"